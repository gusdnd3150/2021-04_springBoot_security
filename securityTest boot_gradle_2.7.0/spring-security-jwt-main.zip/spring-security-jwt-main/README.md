# Spring Security + JWT Example
- Valid와 Exception처리는 되어있지 않습니다.
## 개발 스펙
- Java(11)
- Amazon Corretto(11)
- Spring Boot(2.5.4) - gradle
- Spring Security(boot-starter)
- JWT(0.9.1)
- JPA(boot-starter)
- lombok